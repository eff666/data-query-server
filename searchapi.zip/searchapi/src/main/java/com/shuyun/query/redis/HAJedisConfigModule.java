package com.shuyun.query.redis;

public class HAJedisConfigModule /*implements Module*/ {

    /*@Override
    public void configure(Binder binder) {
        binder.bind(Validator.class).toInstance(Validation.buildDefaultValidatorFactory().getValidator());
        binder.bind(JsonConfigurator.class);
    }*/
}
