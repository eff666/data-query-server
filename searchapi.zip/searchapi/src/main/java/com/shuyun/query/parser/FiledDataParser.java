package com.shuyun.query.parser;

/**
 * Created by shuyun on 2016/7/21.
 */
public class FiledDataParser {

    private String validate_name;
    private String validate_value;

    public String getValidate_name() {
        return validate_name;
    }

    public void setValidate_name(String validate_name) {
        this.validate_name = validate_name;
    }

    public String getValidate_value() {
        return validate_value;
    }

    public void setValidate_value(String validate_value) {
        this.validate_value = validate_value;
    }
}
