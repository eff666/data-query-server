package com.shuyun.query.akka.http.parser;

public enum ParserStatus {
	START,
	ARRAY_START,
	OBJECT_START,
	OBJECT_END
}
