package com.shuyun.query.meta;

/**
 * Created by wanghaiwei on 2016/1/20.
 */
public enum FileType {
    collect,order,weblog_followup,weblog_pc;
}
