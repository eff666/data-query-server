package com.shuyun.query.meta;

/**
 * Created by shuyun on 2016/7/27.
 */
public class ValidateResult {
    private String flag;
    private String result;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
