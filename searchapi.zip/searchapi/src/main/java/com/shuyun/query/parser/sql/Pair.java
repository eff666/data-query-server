package com.shuyun.query.parser.sql;

public class Pair<T1, T2> {
	T1 t1;
	T2 t2;

	public Pair(T1 t1, T2 t2) {
		this.t1 = t1;
		this.t2 = t2;
	}

	public T1 getT1() {
		return t1;
	}

	public T2 getT2() {
		return t2;
	}

	@Override
	public String toString() {
		return "Pair{" +
				"t1=" + t1 +
				", t2=" + t2 +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Pair<?, ?> pair = (Pair<?, ?>) o;

		if (t1 != null ? !t1.equals(pair.t1) : pair.t1 != null) return false;
		return !(t2 != null ? !t2.equals(pair.t2) : pair.t2 != null);

	}

	@Override
	public int hashCode() {
		int result = t1 != null ? t1.hashCode() : 0;
		result = 31 * result + (t2 != null ? t2.hashCode() : 0);
		return result;
	}
}