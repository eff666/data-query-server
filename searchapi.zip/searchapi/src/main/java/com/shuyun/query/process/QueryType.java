package com.shuyun.query.process;


public enum QueryType {

	SEARCH, FILTER, GROUPBY, TRADE;

}
