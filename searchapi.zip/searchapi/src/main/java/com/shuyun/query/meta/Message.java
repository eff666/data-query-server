package com.shuyun.query.meta;

/**
 * Created by wanghaiwei on 2015/8/29.
 */
public class Message {

    private String flag;
    private String msg;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
